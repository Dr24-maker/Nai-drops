const form = document.querySelector('form');
form.addEventListener('submit', (event) => {
  event.preventDefault(); // prevent form from submitting

  const distance = parseInt(document.getElementById('distance').value);
  const price = parseInt(document.getElementById('price').value);
  const payment = document.getElementById('payment').value;

  // perform calculations and display results
  const deliveryFee = distance * 5; // assuming delivery fee is KES 5 per
